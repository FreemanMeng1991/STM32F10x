#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"	 
#include "adc.h"
#include "dma.h" 

int main(void)
{	 
    float ch8_val,ch9_val,ch10_val,ch11_val,ch12_val,ch13_val,ch14_val,ch15_val;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
    delay_init();	    	 //��ʱ������ʼ��	  
    uart_init(115200);	 	//���ڳ�ʼ��Ϊ115200
    LED_Init();			     //LED�˿ڳ�ʼ��	
    DMA_Config(); 
    ADC_Channel_Config();        
    Adc_Init();		  		//ADC��ʼ��   
    while(1)
    {
        ch8_val  = (ADC_DualConvertedValueTab[0]&0xffff)*3.3/4096;
        ch9_val  = ((ADC_DualConvertedValueTab[0])>>16)*3.3/4096;
        ch10_val = (ADC_DualConvertedValueTab[1]&0xffff)*3.3/4096;
        ch11_val = ((ADC_DualConvertedValueTab[1])>>16)*3.3/4096;
        ch12_val = (ADC_DualConvertedValueTab[2]&0xffff)*3.3/4096;
        ch13_val = ((ADC_DualConvertedValueTab[2])>>16)*3.3/4096;
        ch14_val = (ADC_DualConvertedValueTab[3]&0xffff)*3.3/4096;
        ch15_val = ((ADC_DualConvertedValueTab[3])>>16)*3.3/4096;
//        printf("ADC Vals: %d  %d  %d \r\n",ADC_DualConvertedValueTab[0]&0xffff,(ADC_DualConvertedValueTab[0])>>16,ADC_DualConvertedValueTab[0]);
         printf("ADC Vals: %5.2f %5.2f %5.2f %5.2f %5.2f %5.2f %5.2f %5.2f \r\n",ch8_val,ch9_val,ch10_val,ch11_val,ch12_val,ch13_val,ch14_val,ch15_val);
    }
}

