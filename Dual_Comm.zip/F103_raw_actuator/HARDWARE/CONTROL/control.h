#ifndef __CONTROL_H
#define __CONTROL_H	 
#include "sys.h"

#define CTRL_LINE_1 PBout(6) 
#define CTRL_LINE_2 PBout(7) 
#define CTRL_LINE_3 PBout(8) 
#define CTRL_LINE_4 PBout(9) 
#define CTRL_LINE_5 PBout(12) 
#define CTRL_LINE_6 PBout(13) 
#define CTRL_LINE_7 PBout(14) 
#define CTRL_LINE_8 PBout(15) 

extern u8 lo_line_status;
extern u8 lo_op_code; // op-code for execution
extern u8 tx_op_code; // op-code received from LoRa
extern u8 rx_op_code; // op-code needed to transmit via LoRa
extern u16 op_code_complex; // op-code from computer com-port

void key_control(u8 lo_op_code);
void usart_control(u8 lo_op_code);
void ctrl_line_init(void);

		 				    
#endif
