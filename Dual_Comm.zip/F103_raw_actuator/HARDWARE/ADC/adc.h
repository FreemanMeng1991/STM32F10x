#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"

extern u16 lo_ch8_val,lo_ch9_val,lo_ch10_val,lo_ch11_val,lo_ch12_val,lo_ch13_val,lo_ch14_val,lo_ch15_val; // loacl ADC conversions
void ADC_Mode_Config(void);
void ADC_Channel_Config(void);

#endif 
