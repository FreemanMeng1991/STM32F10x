#ifndef __DMA_H
#define __DMA_H
#include "sys.h"  
void DMA_Config(void);
extern __IO uint32_t ADC_DualConvertedValueTab[4];
#endif
