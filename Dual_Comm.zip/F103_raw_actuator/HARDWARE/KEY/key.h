#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"



#define CTRL_KEY1   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8)
#define CTRL_KEY2   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11)
#define CTRL_KEY3   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12)
#define CTRL_KEY4   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)
#define CTRL_KEY5   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_2)
#define CTRL_KEY6   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3) 
#define CTRL_KEY7   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) 
#define CTRL_KEY8   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5) 



#define CTRL_KEY1_PRES   1 
#define CTRL_KEY2_PRES   2 
#define CTRL_KEY3_PRES   3 
#define CTRL_KEY4_PRES   4 
#define CTRL_KEY5_PRES   5 
#define CTRL_KEY6_PRES   6 
#define CTRL_KEY7_PRES   7 
#define CTRL_KEY8_PRES   8 


void key_init(void);//IO��ʼ��
u8   key_scan(u8);  	//����ɨ�躯��					    
#endif
