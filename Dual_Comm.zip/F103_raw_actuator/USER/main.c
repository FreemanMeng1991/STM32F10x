#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "usart.h"	 
#include "adc.h"
#include "dma.h" 
#include "exti.h"
#include "lora.h"
#include "timer.h"
#include "control.h"
#include "string.h"

int main(void)
{	 
    u8 usart1_rx_len,usart3_rx_len,rx_chk=RX_FRAME_LEN;
    u8 idx,key;
    u8 cmd_str[10];

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
    
    delay_init();	    	 //��ʱ������ʼ��	 
    LED_Init();			     //LED�˿ڳ�ʼ��	 
    key_init();          //��ʼ���밴�����ӵ�Ӳ���ӿ�
    ctrl_line_init();
      
    TIM2_Int_Init(10000,7200); //The first param sets the interval based on 0.1ms.
//    TIM3_Int_Init(1000,7200); //The first param sets the interval based on 0.1ms.
//    TIM4_Int_Init(1000,7200); //The first param sets the interval based on 0.1ms.
    
    DMA_Config(); 
    ADC_Channel_Config();        
    ADC_Mode_Config();		  		//ADC��ʼ��  
	
//    EXTIX_Init();
      
    ADC_Cmd(ADC1, ENABLE);                     /* Enable ADC1 */
    ADC_TempSensorVrefintCmd(ENABLE);          /* Enable Vrefint channel17 */  
    ADC_ResetCalibration(ADC1);                /* Enable ADC1 reset calibration register */ 
    while(ADC_GetResetCalibrationStatus(ADC1));/* Check the end of ADC1 reset calibration register */
    ADC_StartCalibration(ADC1);                /* Start ADC1 calibration */
    while(ADC_GetCalibrationStatus(ADC1));     /* Check the end of ADC1 calibration */

    ADC_Cmd(ADC2, ENABLE);                      /* Enable ADC2 */    
    ADC_ResetCalibration(ADC2);                 /* Enable ADC2 reset calibration register */  
    while(ADC_GetResetCalibrationStatus(ADC2)); /* Check the end of ADC2 reset calibration register */  
    ADC_StartCalibration(ADC2);                 /* Start ADC2 calibration */
    while(ADC_GetCalibrationStatus(ADC2));      /* Check the end of ADC2 calibration */

    ADC_SoftwareStartConvCmd(ADC1, ENABLE);     /* Start ADC1 Software Conversion */ 

    while(!DMA_GetFlagStatus(DMA1_FLAG_TC1));   /* Test on DMA1 channel1 transfer complete flag */
    DMA_ClearFlag(DMA1_FLAG_TC1);               /* Clear DMA1 channel1 transfer complete flag */
    
    for(idx=0;idx<4;idx++)
    {LED1 = !LED1;
     LED0 = !LED0;
     delay_ms(300);  
    }
   
    
    USART1_Init(115200);	 
    USART2_Init(19200);	
    USART3_Init(19200);	

 

   
    while(1)
    {  
        
        
        if(USART1_RX_STA&0x8000)
		{	
                usart1_rx_len=USART1_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
                for(idx=0;idx<usart1_rx_len;idx++)
                { cmd_str[idx] = USART1_RX_BUF[idx];
                //				USART_SendData(USART1, USART1_RX_BUF[t]);//�򴮿�1��������
                //				while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
                //              LED1=!LED1;
                }

                op_code_complex = atoi(cmd_str);
                lo_op_code = op_code_complex;
                usart_control(lo_op_code);
//                printf("\nRecv: %d, Operation: %d,%d\n",idx,lo_op_code,atoi(cmd_str));
                memset(cmd_str, 0, sizeof cmd_str);  
                USART1_RX_STA=0;
//                 printf("Re: %d, Lo: %d, Pr: %d\r\n",op_code_complex,lo_op_code,pr_op_code);
        }
        else
        {
            key = key_scan(0);
            key_control(key); 
            tx_op_code = (op_code_complex&0xFF00)>>8;
            
//            printf("Re: %d, Combo: %d, Lo: %d, Pr: %d\r\n",Usart3_rx_len,op_code_complex,lo_op_code,pr_op_code);       
//            printf("Local(%d): %d %d %d %d %d %d %d %d %d\r\n", TX_FRAME_LEN,lo_ch8_val,lo_ch9_val,lo_ch10_val,lo_ch11_val,lo_ch12_val,lo_ch13_val,lo_ch14_val,lo_ch15_val,lo_line_status);
//            printf("Peer_F407(%2d) : %4d %4d %4d %4d %4d %4d %4d %4d %3d %3d\r\n", Usart3_rx_len,pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,pr_line_status,pr_op_code);
            
//            if (!(Usart3_rx_len%rx_chk))
//                printf("%4d %4d %4d %4d %4d %4d %4d %4d %3d %4d %4d %4d %4d %4d %4d %4d %4d %3d %3d\r\n",
//                lo_ch8_val,lo_ch9_val,lo_ch10_val,lo_ch11_val,lo_ch12_val,lo_ch13_val,lo_ch14_val,lo_ch15_val,lo_line_status,
//                pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,pr_line_status,pr_op_code);
//            printf("Peer(%d) : %d %d %d %d %d %d %d %d %d\r\n", Usart3_rx_len,pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,pr_line_status);
		}
        
        
        
        
        
        
        /* Poll local data */
        /* For paticular purpose test only */
//        lo_ch8_val  = 0x3333;
//        lo_ch9_val  = 0x3333;
//        lo_ch10_val = 0x3333;
//        lo_ch11_val = 0x3333;
//        lo_ch12_val = 0x3333;
//        lo_ch13_val = 0x3333;
//        lo_ch14_val = 0x3333;
//        lo_ch15_val = 0x3333;
        
        /* For Production */
        lo_ch8_val  = ADC_DualConvertedValueTab[0]&0x0fff;
        lo_ch9_val  = ((ADC_DualConvertedValueTab[0])>>16)&0x0fff;
        lo_ch10_val = ADC_DualConvertedValueTab[1]&0x0fff;
        lo_ch11_val = ((ADC_DualConvertedValueTab[1])>>16)&0x0fff;
        lo_ch12_val = ADC_DualConvertedValueTab[2]&0x0fff;
        lo_ch13_val = ((ADC_DualConvertedValueTab[2])>>16)&0x0fff;
        lo_ch14_val = ADC_DualConvertedValueTab[3]&0x0fff;
        lo_ch15_val = ((ADC_DualConvertedValueTab[3])>>16)&0x0fff;
        lo_line_status = (CTRL_LINE_1<<0)|(CTRL_LINE_2<<1)|(CTRL_LINE_3<<2)|(CTRL_LINE_4<<3)|
                         (CTRL_LINE_5<<4)|(CTRL_LINE_6<<5)|(CTRL_LINE_7<<6)|(CTRL_LINE_8<<7);
                
        /*  Lora Header */
        #if TRANSPARENT_UART
        #else
        LORA_TX_DATA[0] = (DEVICE_ID&0xFF00)>>8;
        LORA_TX_DATA[1] = DEVICE_ID&0x00FF;
        LORA_TX_DATA[2] = CHANNEL;
        #endif
        /*  Lora Payloads */
        LORA_TX_DATA[0+H_OFFSET] = (lo_ch8_val&0xFF00)>>8;
        LORA_TX_DATA[1+H_OFFSET] = lo_ch8_val&0x00FF;
        LORA_TX_DATA[2+H_OFFSET] = (lo_ch9_val&0xFF00)>>8;
        LORA_TX_DATA[3+H_OFFSET] = lo_ch9_val&0x00FF;
        LORA_TX_DATA[4+H_OFFSET] = (lo_ch10_val&0xFF00)>>8;  
        LORA_TX_DATA[5+H_OFFSET] = lo_ch10_val&0x00FF;
        LORA_TX_DATA[6+H_OFFSET] = (lo_ch11_val&0xFF00)>>8;
        LORA_TX_DATA[7+H_OFFSET] = lo_ch11_val&0x00FF;
        LORA_TX_DATA[8+H_OFFSET] = (lo_ch12_val&0xFF00)>>8;
        LORA_TX_DATA[9+H_OFFSET] = lo_ch12_val&0x00FF;
        LORA_TX_DATA[10+H_OFFSET] = (lo_ch13_val&0xFF00)>>8;
        LORA_TX_DATA[11+H_OFFSET] = lo_ch13_val&0x00FF;
        LORA_TX_DATA[12+H_OFFSET] = (lo_ch14_val&0xFF00)>>8;
        LORA_TX_DATA[13+H_OFFSET] = lo_ch14_val&0x00FF;
        LORA_TX_DATA[14+H_OFFSET] = (lo_ch15_val&0xFF00)>>8;   
        LORA_TX_DATA[15+H_OFFSET] = lo_ch15_val&0x00FF;
        LORA_TX_DATA[16+H_OFFSET] = lo_line_status;
        LORA_TX_DATA[17+H_OFFSET] = tx_op_code;
        /*  Lora Tail */
        LORA_TX_DATA[18+H_OFFSET] = 0x0D;
        LORA_TX_DATA[19+H_OFFSET] = 0x0A;
        USART2_LoRa_Send(LORA_TX_DATA,TX_FRAME_LEN);
		LED0=!LED0;
        
//        printf("PEER_F407: Recv: %2d, Lo-op: %3d, Pr-op: %3d Sentinel: %3d \r\n",Usart3_rx_len,lo_op_code,rx_op_code,sentinel);

        if (Usart3_rx_len == 2*rx_chk)
        printf("%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\r\n",
        lo_ch8_val,lo_ch9_val,lo_ch10_val,lo_ch11_val,lo_ch12_val,lo_ch13_val,lo_ch14_val,lo_ch15_val,
        pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,
        lo_line_status,pr_line_status,rx_op_code,sentinel);
        
//        printf("%4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %3d %4d %3d %3d %3d\r\n",
//        lo_ch8_val,lo_ch9_val,lo_ch10_val,lo_ch11_val,lo_ch12_val,lo_ch13_val,lo_ch14_val,lo_ch15_val,
//        pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,
//        lo_line_status,pr_line_status,rx_op_code,sentinel);

   
   }
}

