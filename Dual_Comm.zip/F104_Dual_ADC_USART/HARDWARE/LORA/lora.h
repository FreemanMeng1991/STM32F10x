#ifndef __LORA_H
#define __LORA_H
#include "sys.h"

#define DEVICE_ID    0
#define CHANNEL      0
#define TAIL         2
#define PAYLOAD_LEN  18  // data length (in byte)


#define TRANSPARENT_UART  0 // Set 1 for transparent transmission, set 0 for P2P transmission 

#if TRANSPARENT_UART
    #define H_OFFSET   0
#else
    #define H_OFFSET   3
#endif

#define TX_FRAME_LEN   PAYLOAD_LEN+H_OFFSET+TAIL // data length (in byte)
#define RX_FRAME_LEN   (TX_FRAME_LEN-TAIL)

extern u8  LORA_TX_DATA[TX_FRAME_LEN];
extern u8  LORA_RX_DATA[RX_FRAME_LEN];
extern u16 pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,pr_line_status; // peer ADC conversions
void USART1_LoRa_Send(u8 byte_arr[],u8 cnt);
void USART2_LoRa_Send(u8 byte_arr[],u8 cnt);
void USART3_LoRa_Send(u8 byte_arr[],u8 cnt);
#endif
