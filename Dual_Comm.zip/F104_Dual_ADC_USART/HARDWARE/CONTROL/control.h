#ifndef __CONTROL_H
#define __CONTROL_H	 
#include "sys.h"

extern u8 lo_op_code; // op-code for execution
extern u8 tx_op_code; // op-code received from LoRa
extern u8 rx_op_code; // op-code needed to transmit via LoRa
extern u16 op_code_complex; // op-code from computer com-port

void key_control(u8 lo_op_code);
void usart_control(u8 lo_op_code);

		 				    
#endif
