#include "key.h"
#include "led.h"

u8 stop = 0;
u8 lo_op_code; // op-code for execution
u8 tx_op_code; // op-code received from LoRa
u8 rx_op_code; // op-code needed to transmit via LoRa
u16 op_code_complex; // op-code from computer com-port

void key_control(u8 lo_op_code)
{ 
    switch(lo_op_code)
    { case CTRL_KEY1_PRES:
        {   if(stop) break;
            CTRL_LINE_1 = 0; CTRL_LINE_2 = 0; CTRL_LINE_3 = 0; CTRL_LINE_4 = 1;
            CTRL_LINE_5 = 0; CTRL_LINE_6 = 0; CTRL_LINE_7 = 0; CTRL_LINE_8 = 1;
            break;
        }
      case CTRL_KEY2_PRES:
        {   if(stop) break;
            CTRL_LINE_1 = 0; CTRL_LINE_2 = 0; CTRL_LINE_3 = 1; CTRL_LINE_4 = 0;
            CTRL_LINE_5 = 0; CTRL_LINE_6 = 0; CTRL_LINE_7 = 1; CTRL_LINE_8 = 0;
            break;
        }
      case CTRL_KEY3_PRES:
        {   if(stop) break;
            CTRL_LINE_1 = 0; CTRL_LINE_2 = 0; CTRL_LINE_3 = 1; CTRL_LINE_4 = 1;
            CTRL_LINE_5 = 0; CTRL_LINE_6 = 0; CTRL_LINE_7 = 1; CTRL_LINE_8 = 1;
            break;
        }
      case CTRL_KEY4_PRES:
        {   if(stop) break;
            CTRL_LINE_1 = 0; CTRL_LINE_2 = 1; CTRL_LINE_3 = 0; CTRL_LINE_4 = 0;
            CTRL_LINE_5 = 0; CTRL_LINE_6 = 1; CTRL_LINE_7 = 0; CTRL_LINE_8 = 0;
            break;
        }
      case CTRL_KEY5_PRES:
        {   if(stop) break;
            CTRL_LINE_1 = 0; CTRL_LINE_2 = 1; CTRL_LINE_3 = 0; CTRL_LINE_4 = 1;
            CTRL_LINE_5 = 0; CTRL_LINE_6 = 1; CTRL_LINE_7 = 0; CTRL_LINE_8 = 1;
            break;
        }
      case CTRL_KEY6_PRES:
        {   if(stop) break;
            CTRL_LINE_1 = 0; CTRL_LINE_2 = 1; CTRL_LINE_3 = 1; CTRL_LINE_4 = 0;
            CTRL_LINE_5 = 0; CTRL_LINE_6 = 1; CTRL_LINE_7 = 1; CTRL_LINE_8 = 0;
            break;
        }
      case CTRL_KEY7_PRES:
        { CTRL_LINE_1 = 0; CTRL_LINE_2 = 0; CTRL_LINE_3 = 0; CTRL_LINE_4 = 0;
          CTRL_LINE_5 = 0; CTRL_LINE_6 = 0; CTRL_LINE_7 = 0; CTRL_LINE_8 = 0;
          stop = !stop;
          break;
        }
      
   }
}



void usart_control(u8 lo_op_code)
{ 
    u8 L1_Out,L2_Out,L3_Out,L4_Out,L5_Out,L6_Out,L7_Out,L8_Out;
//    printf("Op_code: %d\n",lo_op_code);
    L1_Out = ((lo_op_code&0x01)>>0);
    L2_Out = ((lo_op_code&0x02)>>1);
    L3_Out = ((lo_op_code&0x04)>>2);
    L4_Out = ((lo_op_code&0x08)>>3);
    L5_Out = ((lo_op_code&0x10)>>4);
    L6_Out = ((lo_op_code&0x20)>>5);
    L7_Out = ((lo_op_code&0x40)>>6);
    L8_Out = ((lo_op_code&0x80)>>7);
//    printf("%d %d %d %d %d %d %d %d \n",L8_Out,L7_Out,L6_Out,L5_Out,L4_Out,L3_Out,L2_Out,L1_Out);
    
    CTRL_LINE_1 =  L1_Out;
    CTRL_LINE_2 =  L2_Out;
    CTRL_LINE_3 =  L3_Out;
    CTRL_LINE_4 =  L4_Out;
    CTRL_LINE_5 =  L5_Out;
    CTRL_LINE_6 =  L6_Out;
    CTRL_LINE_7 =  L7_Out;
    CTRL_LINE_8 =  L8_Out;
    
}
