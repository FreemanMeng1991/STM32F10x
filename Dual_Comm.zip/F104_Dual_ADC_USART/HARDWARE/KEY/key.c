#include "led.h"
#include "delay.h"

u8 KEY_Scan(u8 mode)
{	 
	static u8 key_up=1;//�������ɿ���־
	if(mode)key_up=1;  //֧������		  
	if(key_up&&!(CTRL_KEY1==1&&CTRL_KEY2==1&&CTRL_KEY3==1&&CTRL_KEY4==1&&CTRL_KEY5==1&&CTRL_KEY6==1&&CTRL_KEY7==1&&CTRL_KEY8==1))
	{   
       
        delay_ms(10);//ȥ����  
        if(!(CTRL_KEY1==1&&CTRL_KEY2==1&&CTRL_KEY3==1&&CTRL_KEY4==1&&CTRL_KEY5==1&&CTRL_KEY6==1&&CTRL_KEY7==1&&CTRL_KEY8==1))	
		{
            key_up=0;
            if (CTRL_KEY1==0)return CTRL_KEY1_PRES;
            else if(CTRL_KEY2==0)return CTRL_KEY2_PRES;
            else if(CTRL_KEY3==0)return CTRL_KEY3_PRES;
            else if(CTRL_KEY4==0)return CTRL_KEY4_PRES;
            else if(CTRL_KEY5==0)return CTRL_KEY5_PRES;
            else if(CTRL_KEY6==0)return CTRL_KEY6_PRES;
            else if(CTRL_KEY7==0)return CTRL_KEY7_PRES;
            else if(CTRL_KEY8==0)return CTRL_KEY8_PRES;
        }
	}else if(CTRL_KEY1==1&&CTRL_KEY2==1&&CTRL_KEY3==1&&CTRL_KEY4==1&&CTRL_KEY5==1&&CTRL_KEY6==1&&CTRL_KEY7==1&&CTRL_KEY8==1)key_up=1; 	    
 	return 0;// �ް�������
}
