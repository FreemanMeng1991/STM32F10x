#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "adc.h"
#include "dma.h"
#include "lora.h"
#include "string.h"
#include "timer.h"
#include "control.h"
#include <stdio.h>


int main(void)
{ 

    u8 usart1_rx_len,usart3_rx_len,rx_chk=RX_FRAME_LEN;
    u8 idx,key;
    u8 cmd_str[10];
    u16 test_val=0x0;
//    uint16_t aADCDualConvertedValue[8] = {4095,0,4095,0,4095,0,0,0};
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
    
    // Setup clocks
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE); // For USART
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE); // For Ctrl_ley & ADC
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE); // For Ctrl_lines & ADC
//    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE); // For LCD
//    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE); // For LCD & On-board key
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF,ENABLE); // For LED
//    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG,ENABLE); // For LCD
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE); //DMA Clock
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); //ADC clock
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, ENABLE); 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);  //USART1 Clock
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);  //USART2 Clock
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);//USART3 Clock
//	RCC_AHB3PeriphClockCmd(RCC_AHB3Periph_FSMC,ENABLE);  //FSMC Clock
	
    
	delay_init(168);    //��ʼ����ʱ����

    TIM2_Int_Init(10000,8400);   
//    TIM3_Int_Init(500,8400);
//    TIM4_Int_Init(2000,8400);
    LED_Init();
    GPIO_Config();
    DMA_Config();
	Adc_Init();         //��ʼ��ADC
    ADC_MultiModeDMARequestAfterLastTransferCmd(ENABLE);
    ADC_Cmd(ADC1, ENABLE);  /* Enable ADC1 */
    ADC_Cmd(ADC2, ENABLE); /* Enable ADC2 */ 
    ADC_SoftwareStartConv(ADC1);/* Start ADC1 Software Conversion */
   
    
    for(idx=0;idx<4;idx++)
    {LED1 = !LED1;
     LED0 = !LED0;
     delay_ms(300);  
    }
    
    USART1_Init(115200);	//��ʼ�����ڲ�����Ϊ115200 
    USART2_Init(19200);
    USART3_Init(19200);


    
	while(1)
	{   
        
        if(USART1_RX_STA&0x8000)
        {	
            usart1_rx_len=USART1_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
            for(idx=0;idx<usart1_rx_len;idx++)
            {   cmd_str[idx] = USART1_RX_BUF[idx];
//				USART_SendData(USART1, USART1_RX_BUF[t]);//�򴮿�1��������
//				while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
//                LED1=!LED1;
            }
            op_code_complex = atoi(cmd_str);
            lo_op_code = op_code_complex;  
            
            usart_control(lo_op_code);
//            printf("\nRecv: %d, Operation: %d,%d\n",idx,lo_op_code,atoi(cmd_str));
            memset(cmd_str, 0, sizeof cmd_str);  
            USART1_RX_STA=0;
//            printf("Re: %d, Lo: %d, Pr: %d\r\n",op_code_complex,lo_op_code,pr_op_code);
        }
        else
        {   
            key = KEY_Scan(0);
            key_control(key);
            tx_op_code = (op_code_complex&0xFF00)>>8;
//            printf("Local(%d): %d %d %d %d %d %d %d %d %d\r\n", TX_FRAME_LEN,lo_ch8_val,lo_ch9_val,lo_ch10_val,lo_ch11_val,lo_ch12_val,lo_ch13_val,lo_ch14_val,lo_ch15_val,lo_line_status);
//            printf("Peer_F103(%2d) : %4d %4d %4d %4d %4d %4d %4d %4d %3d %3d\r\n", Usart3_rx_len,pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,pr_line_status,pr_op_code);
           
//            if (!(Usart3_rx_len%rx_chk))
//            printf("%4d %4d %4d %4d %4d %4d %4d %4d %3d %4d %4d %4d %4d %4d %4d %4d %4d %3d %3d\r\n",
//                   lo_ch8_val,lo_ch9_val,lo_ch10_val,lo_ch11_val,lo_ch12_val,lo_ch13_val,lo_ch14_val,lo_ch15_val,lo_line_status,
//                   pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,pr_line_status,pr_op_code);
//            printf("Peer(%d) : %d %d %d %d %d %d %d %d %d\r\n", Usart3_rx_len,pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,pr_line_status);
        }
         
        /* Poll local data */
        /* For paticular purpose test only */
//        lo_ch8_val  = test_val;
//        lo_ch9_val  = test_val;
//        lo_ch10_val = aADCDualConvertedValue[2];
//        lo_ch11_val = test_val;
//        lo_ch12_val = test_val;
//        lo_ch13_val = test_val;
//        lo_ch14_val = test_val;
//        lo_ch15_val = test_val;
//        test_val++;
//        if (test_val > 4096)
//            test_val = 0;
           
        
        /* For Production */
        lo_ch8_val = aADCDualConvertedValue[0];
        lo_ch9_val = aADCDualConvertedValue[1];
        lo_ch10_val = aADCDualConvertedValue[2];
        lo_ch11_val = aADCDualConvertedValue[3];
        lo_ch12_val = aADCDualConvertedValue[4];
        lo_ch13_val = aADCDualConvertedValue[5];
        lo_ch14_val = aADCDualConvertedValue[6];
        lo_ch15_val = aADCDualConvertedValue[7];
        lo_line_status = (CTRL_LINE_1<<0)|(CTRL_LINE_2<<1)|(CTRL_LINE_3<<2)|(CTRL_LINE_4<<3)|
                         (CTRL_LINE_5<<4)|(CTRL_LINE_6<<5)|(CTRL_LINE_7<<6)|(CTRL_LINE_8<<7);

                
        /*  Lora Header */
        #if TRANSPARENT_UART
        #else
        LORA_TX_DATA[0] = (DEVICE_ID&0xFF00)>>8;
        LORA_TX_DATA[1] = DEVICE_ID&0x00FF;
        LORA_TX_DATA[2] = CHANNEL;
        #endif
        /*  Lora Payloads */
        LORA_TX_DATA[0+H_OFFSET] = (lo_ch8_val&0xFF00)>>8;
        LORA_TX_DATA[1+H_OFFSET] = lo_ch8_val&0x00FF;
        LORA_TX_DATA[2+H_OFFSET] = (lo_ch9_val&0xFF00)>>8;
        LORA_TX_DATA[3+H_OFFSET] = lo_ch9_val&0x00FF;
        LORA_TX_DATA[4+H_OFFSET] = (lo_ch10_val&0xFF00)>>8;  
        LORA_TX_DATA[5+H_OFFSET] = lo_ch10_val&0x00FF;
        LORA_TX_DATA[6+H_OFFSET] = (lo_ch11_val&0xFF00)>>8;
        LORA_TX_DATA[7+H_OFFSET] = lo_ch11_val&0x00FF;
        LORA_TX_DATA[8+H_OFFSET] = (lo_ch12_val&0xFF00)>>8;
        LORA_TX_DATA[9+H_OFFSET] = lo_ch12_val&0x00FF;
        LORA_TX_DATA[10+H_OFFSET] = (lo_ch13_val&0xFF00)>>8;
        LORA_TX_DATA[11+H_OFFSET] = lo_ch13_val&0x00FF;
        LORA_TX_DATA[12+H_OFFSET] = (lo_ch14_val&0xFF00)>>8;
        LORA_TX_DATA[13+H_OFFSET] = lo_ch14_val&0x00FF;
        LORA_TX_DATA[14+H_OFFSET] = (lo_ch15_val&0xFF00)>>8;   
        LORA_TX_DATA[15+H_OFFSET] = lo_ch15_val&0x00FF;
        LORA_TX_DATA[16+H_OFFSET] = lo_line_status;
        LORA_TX_DATA[17+H_OFFSET] = tx_op_code;
        /*  Lora Tail */
        LORA_TX_DATA[18+H_OFFSET] = 0x0D;
        LORA_TX_DATA[19+H_OFFSET] = 0x0A;
        USART2_LoRa_Send(LORA_TX_DATA,TX_FRAME_LEN);
		LED0=!LED0;
        
//        printf("Peer_F103: Recv: %2d, Lo-op: %3d, Pr-op: %3d Sentinel: %3d \r\n",Usart3_rx_len,lo_op_code,rx_op_code,sentinel);

        if (Usart3_rx_len == 2*rx_chk)
        printf("%4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %3d %4d %3d %3d %3d\r\n",
        lo_ch8_val,lo_ch9_val,lo_ch10_val,lo_ch11_val,lo_ch12_val,lo_ch13_val,lo_ch14_val,lo_ch15_val,
        pr_ch8_val,pr_ch9_val,pr_ch10_val,pr_ch11_val,pr_ch12_val,pr_ch13_val,pr_ch14_val,pr_ch15_val,
        lo_line_status,pr_line_status,rx_op_code,sentinel);

    }

}
    





