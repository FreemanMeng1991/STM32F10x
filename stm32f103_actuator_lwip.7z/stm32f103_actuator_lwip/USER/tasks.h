#ifndef _TASKS_H
#define _TASKS_H

int create_start_task(void);
void led0_blink(void);
void led1_blink(void);
void beeper_ring(void);


#endif 
