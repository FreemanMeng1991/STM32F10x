#ifndef _OP_CODE_H
#define _OP_CODE_H

#define BLINK_LED0       1
#define BLINK_LED1       2
#define BEEPER_RING      3
#define TRI_BLINK_LED1   4
#define TOGGLE_CL1       5
#define TOGGLE_CL2       6
#define TOGGLE_CL3       7
#define TOGGLE_CL4       8
#define TOGGLE_CL5       9
#define TOGGLE_CL6       10
#define TOGGLE_CL7       11
#define TOGGLE_CL8       12

#endif 
