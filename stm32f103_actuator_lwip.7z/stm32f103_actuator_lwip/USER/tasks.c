#include "tasks.h"
#include "op_code.h"
#include "mail_box.h"
#include "includes.h"
#include "led.h"
#include "key.h"
#include "delay.h"
#include "tcp_server_demo.h"

//LED����
#define KEY_TASK_PRIO		3
#define KEY_STK_SIZE		128
OS_STK	KEY_TASK_STK[KEY_STK_SIZE];
void key_task(void *pdata);  


//LED����
#define LED_TASK_PRIO		4
#define LED_STK_SIZE		64
OS_STK	LED_TASK_STK[LED_STK_SIZE];
void led_task(void *pdata);  

//KEY����
#define TCP_UPLOAD_PRIO 		10   //�������ȼ�
#define TCP_STK_PRIO		128	//�����ջ��С
OS_STK TCP_UPLOAD_STK[TCP_STK_PRIO];//�����ջ
void tcp_data_upload_task(void *pdata);   //������


//START����
#define START_TASK_PRIO		12        //�������ȼ�
#define START_STK_SIZE		128       //�����ջ��С
OS_STK START_TASK_STK[START_STK_SIZE];//�����ջ

void toggle_ctrl_line1(void);
void toggle_ctrl_line2(void);
void toggle_ctrl_line3(void);
void toggle_ctrl_line4(void);
void toggle_ctrl_line5(void);
void toggle_ctrl_line6(void);
void toggle_ctrl_line7(void);
void toggle_ctrl_line8(void);


void tcp_data_upload_task(void *pdata)
{
	while(1)
	{
        tcp_server_flag |= LWIP_SEND_DATA; //���LWIP������Ҫ����
 	}
}


void led_task(void *pdata)
{
	u8 code,key;	
	u8 err,err1;	
	while(1)
	{    code=(u8)OSMboxPend(OP_CODE,10,&err);   
         key =(u8)OSMboxPend(MSG_KEY,10,&err1); 
         if (!key)
         { switch(code)
            {
            case BLINK_LED0    : led0_blink();break;
            case BLINK_LED1    : led1_blink();break;
            case TRI_BLINK_LED1: beeper_ring();break;
            case TOGGLE_CL1 : toggle_ctrl_line1();break;
            case TOGGLE_CL2 : toggle_ctrl_line2();break;
            case TOGGLE_CL3 : toggle_ctrl_line3();break;
            case TOGGLE_CL4 : toggle_ctrl_line4();break;
            case TOGGLE_CL5: toggle_ctrl_line5();break;
            case TOGGLE_CL6 : toggle_ctrl_line6();break;
            case TOGGLE_CL7 : toggle_ctrl_line7();break;
            case TOGGLE_CL8 : toggle_ctrl_line8();break;
            default: break;
            }
         }
         else
         {  switch(key)
            {
            case KEY0_PRES : led0_blink();break;
            case KEY1_PRES : led1_blink();break;
            case KEY2_PRES : beeper_ring();break;
            case KEY5_PRES : toggle_ctrl_line1();break;
            case KEY6_PRES : toggle_ctrl_line2();break;
            case KEY7_PRES : toggle_ctrl_line3();break;
            case KEY8_PRES : toggle_ctrl_line4();break;
            case KEY9_PRES : toggle_ctrl_line5();break;
            case KEY10_PRES : toggle_ctrl_line6();break;
            case KEY11_PRES : toggle_ctrl_line7();break;
            case KEY12_PRES : toggle_ctrl_line8();break;
            default: break;
            } 
         }
	   	 delay_ms(50);
	}				
}



void led1_blink(void)
{
    printf("run led1_blink \r\n");	
    LED1=!LED1;
    delay_ms(50);
    LED1=!LED1;
    delay_ms(50);
    LED1=!LED1;
    delay_ms(50);
    LED1=!LED1;
    delay_ms(50);
}


void led0_blink(void)
{
    printf("run led0_blink \r\n");	
    LED0=!LED0;
    delay_ms(50);
    LED0=!LED0;
    delay_ms(50);
    LED0=!LED0;
    delay_ms(50);
    LED0=!LED0;
    delay_ms(50);
}


void beeper_ring(void)
{
    printf("run beeper_ring \r\n");	
    LED1=!LED1;
    LED0=!LED0;
    delay_ms(50);
    LED1=!LED1;
    LED0=!LED0;
    delay_ms(50);
    LED1=!LED1;
    LED0=!LED0;
    delay_ms(50);
    LED1=!LED1;
    LED0=!LED0;
    delay_ms(50);
}


void toggle_ctrl_line1(void)
{printf("toggle_ctrl_line1 \r\n");	
 CTRL_LINE_1 = !CTRL_LINE_1;
delay_ms(1500);}

void toggle_ctrl_line2(void)
{CTRL_LINE_2 = !CTRL_LINE_2;}

void toggle_ctrl_line3(void)
{CTRL_LINE_3 = !CTRL_LINE_3;}

void toggle_ctrl_line4(void)
{CTRL_LINE_4 = !CTRL_LINE_4;}

void toggle_ctrl_line5(void)
{CTRL_LINE_5 = !CTRL_LINE_5;}

void toggle_ctrl_line6(void)
{CTRL_LINE_6 = !CTRL_LINE_6;}

void toggle_ctrl_line7(void)
{CTRL_LINE_7 = !CTRL_LINE_7;}

void toggle_ctrl_line8(void)
{CTRL_LINE_8 = !CTRL_LINE_8;}
    



void key_task(void *pdata)
{	
	u8 key;		    						 
	while(1)
	{
		key=KEY_Scan(1);   
		if(key)OSMboxPost(MSG_KEY,(void*)key);//������Ϣ
 		delay_ms(100);
        printf("run key_task %d\r\n",key);
	}
}

//start����
void start_task(void *pdata)
{
	OS_CPU_SR cpu_sr;
	pdata = pdata ;
	OP_CODE=OSMboxCreate((void*)0);	//������Ϣ����
    MSG_KEY=OSMboxCreate((void*)0);	//������Ϣ����
	OSStatInit();  			//��ʼ��ͳ������
	OS_ENTER_CRITICAL();  	//���ж�
    OSTaskCreate(key_task,(void*)0,(OS_STK*)&KEY_TASK_STK[KEY_STK_SIZE-1],KEY_TASK_PRIO); 	//����LED����
    OSTaskCreate(led_task,(void*)0,(OS_STK*)&LED_TASK_STK[LED_STK_SIZE-1],LED_TASK_PRIO); 	//����LED����
	OSTaskCreate(tcp_data_upload_task,(void*)0,(OS_STK*)&TCP_UPLOAD_STK[TCP_STK_PRIO-1],TCP_UPLOAD_PRIO); 	//����TCP_UPLOAD����    
	OSTaskSuspend(OS_PRIO_SELF); //����start_task����
	OS_EXIT_CRITICAL();  //���ж�
}

int create_start_task(void)
{
  OSTaskCreate(start_task,(void*)0,(OS_STK*)&START_TASK_STK[START_STK_SIZE-1],START_TASK_PRIO);
}