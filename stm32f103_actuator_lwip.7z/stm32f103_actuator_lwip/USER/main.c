#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "dma.h"
#include "adc.h"
#include "usart.h"	
#include "timer.h"
#include "sram.h"
#include "malloc.h"
#include "string.h"
#include "usmart.h"	
#include "dm9000.h"
#include "lwip/netif.h"
#include "lwip_comm.h"
#include "lwipopts.h"
#include "includes.h"
#include "tcp_server_demo.h"
#include "op_code.h"
#include "mail_box.h"
#include "tasks.h"




OS_EVENT * OP_CODE = NULL;			//TCP command mailbox
OS_EVENT * MSG_KEY = NULL;			//Key command mailbox

int main(void)
{	 
    delay_init();	    	//��ʱ������ʼ��	  
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 	//����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
    uart_init(9600);	 	//���ڳ�ʼ��Ϊ115200
    LED_Init();			    //LED�˿ڳ�ʼ��
    KEY_Init();	 			//��ʼ������
    DMA_Config();
    ADC_Channel_Config();
    Adc_Init();             //ADC Initialization
    usmart_dev.init(72);	//��ʼ��USMART		 
//    FSMC_SRAM_Init();		//��ʼ���ⲿSRAM
//    my_mem_init(SRAMIN);	//��ʼ���ڲ��ڴ��
//    my_mem_init(SRAMEX);	//��ʼ���ⲿ�ڴ��
     
    ADC_Cmd(ADC1, ENABLE);                     /* Enable ADC1 */
    ADC_TempSensorVrefintCmd(ENABLE);          /* Enable Vrefint channel17 */  
    ADC_ResetCalibration(ADC1);                /* Enable ADC1 reset calibration register */ 
    while(ADC_GetResetCalibrationStatus(ADC1));/* Check the end of ADC1 reset calibration register */
    ADC_StartCalibration(ADC1);                /* Start ADC1 calibration */
    while(ADC_GetCalibrationStatus(ADC1));     /* Check the end of ADC1 calibration */

    ADC_Cmd(ADC2, ENABLE);                      /* Enable ADC2 */    
    ADC_ResetCalibration(ADC2);                 /* Enable ADC2 reset calibration register */  
    while(ADC_GetResetCalibrationStatus(ADC2)); /* Check the end of ADC2 reset calibration register */  
    ADC_StartCalibration(ADC2);                 /* Start ADC2 calibration */
    while(ADC_GetCalibrationStatus(ADC2));      /* Check the end of ADC2 calibration */

    ADC_SoftwareStartConvCmd(ADC1, ENABLE);     /* Start ADC1 Software Conversion */ 

    while(!DMA_GetFlagStatus(DMA1_FLAG_TC1));   /* Test on DMA1 channel1 transfer complete flag */
    DMA_ClearFlag(DMA1_FLAG_TC1);               /* Clear DMA1 channel1 transfer complete flag */
 
    OSInit();					//UCOS��ʼ��
    while(lwip_comm_init()) 		//lwip��ʼ��
    {
        printf("lwip_comm_init failed!\n");
    }
    printf("lwip_comm_init Success!\n");
    while(tcp_server_init()) 	                //��ʼ��tcp_server(����tcp_server�߳�)
    {
        printf("tcp_server_init failed!\n");
    }
    printf("tcp_server_init Success!\n"); 	    //TCP Server�����ɹ�

    LED0 = !LED0;
    delay_ms(500);  //��ʱ500ms
    LED0 = !LED0;
    delay_ms(500);  //��ʱ500ms
    create_start_task();
    OSStart(); //����UCOS
}
 



