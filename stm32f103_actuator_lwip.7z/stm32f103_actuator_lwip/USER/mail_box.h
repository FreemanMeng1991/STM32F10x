#ifndef _MAIL_BOX_H
#define _MAIL_BOX_H

#include "ucos_ii.h"
 
extern OS_EVENT * OP_CODE;			//TCP command mailbox
extern OS_EVENT * MSG_KEY;			//Key command mailbox

#endif 
