#ifndef _TASKS_H
#define _TASKS_H

#include <os.h>

void create_user_tasks(void);
void resume_led_g_task(void);
void resume_beeper_task(void);
void resume_recv_task(void);
#endif 