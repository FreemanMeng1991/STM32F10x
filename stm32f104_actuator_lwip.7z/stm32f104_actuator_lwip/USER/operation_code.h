#ifndef _OPERATION_CODE_H
#define _OPERATION_CODE_H

#define BLINK_LED1       0
#define RING_BEEPER      1
#define TRI_BLINK_LED1   3

#endif 