#include "tasks.h"
#include "includes.h"
#include "led.h"
#include "key.h"
#include "beep.h"
#include "delay.h"
#include "tcp_server.h"



//KEY����
#define KEY_TASK_PRIO 		6       //�������ȼ�
#define KEY_STK_SIZE		128	    //�����ջ��С
OS_TCB KeyTaskTCB;                  //������ƿ�
CPU_STK KEY_TASK_STK[KEY_STK_SIZE]; //�����ջ
void key_task(void *pdata);         //������


//data upload task
#define DATA_UPLOAD_TASK_PRIO   30
#define UPLOAD_STK_SIZE		    128
OS_TCB DataUploadTCB;  
CPU_STK	DATA_UPLOAD_TASK_STK[UPLOAD_STK_SIZE];
void tcp_data_upload_task(void *pdata);  

//LED0����
#define LED_TASK_PRIO		7       //�������ȼ�
#define LED_STK_SIZE		128    //�����ջ��С
OS_TCB LedTaskTCB;                  //������ƿ�
CPU_STK	LED_TASK_STK[LED_STK_SIZE]; //�����ջextern OS_TCB KeyTaskTCB;          
void led_task(void *pdata);         //������


//LED1 data receive indicator
#define RECV_TASK_PRIO		9
#define RECV_STK_SIZE		128	    //�����ջ��С
OS_TCB  RecvTaskTCB;
CPU_STK	RECV_TASK_STK[RECV_STK_SIZE];
void recv_task(void *pdata);  

//LED1 blink task
#define LED_G_TASK_PRIO		9
#define LED_G_STK_SIZE		128	    //�����ջ��С
OS_TCB LedGTaskTCB;
CPU_STK	LED_G_TASK_STK[LED_STK_SIZE];
void g_led_task(void *pdata);  

//beeper ring task
#define BEEPER_TASK_PRIO	9
#define BEEPER_STK_SIZE		128	    //�����ջ��С
OS_TCB BeeperTaskTCB;
CPU_STK	BEEPER_TASK_STK[BEEPER_STK_SIZE];
void beeper_task(void *pdata);  


void resume_led_g_task(void);
void resume_beeper_task(void);
void resume_recv_task(void);


void create_user_tasks(void)
{
    OS_ERR err;
    //����LED0����
    OSTaskCreate((OS_TCB 	* )&LedTaskTCB,		
                 (CPU_CHAR	* )"led0 task", 		
                 (OS_TASK_PTR )led_task, 			
                 (void		* )0,					
                 (OS_PRIO	  )LED_TASK_PRIO,     
                 (CPU_STK   * )&LED_TASK_STK[0],	
                 (CPU_STK_SIZE)LED_STK_SIZE/10,	
                 (CPU_STK_SIZE)LED_STK_SIZE,		
                 (OS_MSG_QTY  )0,					
                 (OS_TICK	  )0,					
                 (void   	* )0,					
                 (OS_OPT      )OS_OPT_TASK_STK_CHK|OS_OPT_TASK_STK_CLR,
                 (OS_ERR 	* )&err);	
    //����LED1����
    OSTaskCreate((OS_TCB 	* )&LedGTaskTCB,		
                 (CPU_CHAR	* )"led1 task", 		
                 (OS_TASK_PTR )g_led_task, 			
                 (void		* )0,					
                 (OS_PRIO	  )LED_G_TASK_PRIO,     
                 (CPU_STK   * )&LED_G_TASK_STK[0],	
                 (CPU_STK_SIZE)LED_G_STK_SIZE/10,	
                 (CPU_STK_SIZE)LED_G_STK_SIZE,		
                 (OS_MSG_QTY  )0,					
                 (OS_TICK	  )0,					
                 (void   	* )0,					
                 (OS_OPT      )OS_OPT_TASK_STK_CHK|OS_OPT_TASK_STK_CLR,
                 (OS_ERR 	* )&err);
    // tcp upload task
    OSTaskCreate((OS_TCB 	* )&DataUploadTCB,		
                 (CPU_CHAR	* )"upload task", 		
                 (OS_TASK_PTR )tcp_data_upload_task, 			
                 (void		* )0,					
                 (OS_PRIO	  )DATA_UPLOAD_TASK_PRIO,     
                 (CPU_STK   * )&DATA_UPLOAD_TASK_STK[0],	
                 (CPU_STK_SIZE)UPLOAD_STK_SIZE/10,	
                 (CPU_STK_SIZE)UPLOAD_STK_SIZE,		
                 (OS_MSG_QTY  )0,					
                 (OS_TICK	  )0,					
                 (void   	* )0,					
                 (OS_OPT      )OS_OPT_TASK_STK_CHK|OS_OPT_TASK_STK_CLR,
                 (OS_ERR 	* )&err);		                 
    //����KEY����
    OSTaskCreate((OS_TCB 	* )&KeyTaskTCB,		
                 (CPU_CHAR	* )"key task", 		
                 (OS_TASK_PTR )key_task, 			
                 (void		* )0,					
                 (OS_PRIO	  )KEY_TASK_PRIO,     
                 (CPU_STK   * )&KEY_TASK_STK[0],	
                 (CPU_STK_SIZE)KEY_STK_SIZE/10,	
                 (CPU_STK_SIZE)KEY_STK_SIZE,		
                 (OS_MSG_QTY  )0,					
                 (OS_TICK	  )0,					
                 (void   	* )0,					
                 (OS_OPT      )OS_OPT_TASK_STK_CHK|OS_OPT_TASK_STK_CLR,
                 (OS_ERR 	* )&err);	
    //����BEEPER����
    OSTaskCreate((OS_TCB 	* )&BeeperTaskTCB,		
                 (CPU_CHAR	* )"beeper task", 		
                 (OS_TASK_PTR )beeper_task, 			
                 (void		* )0,					
                 (OS_PRIO	  )BEEPER_TASK_PRIO,     
                 (CPU_STK   * )&BEEPER_TASK_STK[0],	
                 (CPU_STK_SIZE)BEEPER_STK_SIZE/10,	
                 (CPU_STK_SIZE)BEEPER_STK_SIZE,		
                 (OS_MSG_QTY  )0,					
                 (OS_TICK	  )0,					
                 (void   	* )0,					
                 (OS_OPT      )OS_OPT_TASK_STK_CHK|OS_OPT_TASK_STK_CLR,
                 (OS_ERR 	* )&err);	
    //����RECV����
    OSTaskCreate((OS_TCB 	* )&RecvTaskTCB,		
                 (CPU_CHAR	* )"beeper task", 		
                 (OS_TASK_PTR )recv_task, 			
                 (void		* )0,					
                 (OS_PRIO	  )RECV_TASK_PRIO,     
                 (CPU_STK   * )&RECV_TASK_STK[0],	
                 (CPU_STK_SIZE)RECV_STK_SIZE/10,	
                 (CPU_STK_SIZE)RECV_STK_SIZE,		
                 (OS_MSG_QTY  )0,					
                 (OS_TICK	  )0,					
                 (void   	* )0,					
                 (OS_OPT      )OS_OPT_TASK_STK_CHK|OS_OPT_TASK_STK_CLR,
                 (OS_ERR 	* )&err);		                                  
      
}

//key����
void key_task(void *pdata)
{
	u8 key; 
	OS_ERR err;
	while(1)
	{
		key = KEY_Scan(0);
		if(key==KEY0_PRES) //��������
		{
			resume_led_g_task();
//            tcp_server_flag |= LWIP_SEND_DATA; //���LWIP������Ҫ����
		}
		OSTimeDlyHMSM(0,0,0,10,OS_OPT_TIME_HMSM_STRICT,&err); //��ʱ10ms
	}
}

//led����
void led_task(void *pdata)
{
	OS_ERR err;
    printf("LED0\r");
	while(1)
	{
		
        LED0 = !LED0;
        delay_ms(1000);
//		OSTimeDlyHMSM(0,0,0,500,OS_OPT_TIME_HMSM_STRICT,&err); //��ʱ500ms
 	}
}



//led����
void g_led_task(void *pdata)
{
	OS_ERR err;
    
	while(1)
	{  
        LED0 = !LED0;
        delay_ms(100);
        LED1 = !LED1;
        delay_ms(100);
        LED0 = !LED0;
        delay_ms(100);
        LED0 = !LED0;
        delay_ms(100);
        LED0 = !LED0;
        delay_ms(100);
        LED0 = !LED0;
        delay_ms(100);
        OS_TaskSuspend(NULL,&err);
 	}
}

//Upload����
void tcp_data_upload_task(void *pdata)
{
	while(1)
	{
        tcp_server_flag |= LWIP_SEND_DATA; //���LWIP������Ҫ����
 	}
}

//Recv����
void recv_task(void *pdata)
{
	OS_ERR err;
    
    while(1)
	{
        LED0 = !LED0;
        delay_ms(200);
        LED0 = !LED0; 
        OS_TaskSuspend(NULL,&err);
 	}
}


//beeper����
void beeper_task(void *pdata)
{
	OS_ERR err;
	while(1)
	{  
        GPIO_SetBits(GPIOF,GPIO_Pin_8);
        delay_ms(300);
        GPIO_ResetBits(GPIOF,GPIO_Pin_8);
        OS_TaskSuspend(NULL,&err);
 	}
}


void resume_led_g_task(void)
{
    OS_ERR err;
    OS_TaskResume((OS_TCB*)&LedGTaskTCB,&err);
}


void resume_beeper_task(void)
{
    OS_ERR err;
    OS_TaskResume((OS_TCB*)&BeeperTaskTCB,&err);
}


void resume_recv_task(void)
{
    OS_ERR err;
    OS_TaskResume((OS_TCB*)&RecvTaskTCB,&err);
}





