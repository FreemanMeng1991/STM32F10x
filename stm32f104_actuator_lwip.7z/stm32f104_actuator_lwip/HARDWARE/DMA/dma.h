#ifndef __DMA_H
#define __DMA_H
#include "sys.h"  
void DMA_Config(void);
extern __IO uint16_t dual_ADC_val[8];
#endif
